# OJapp Free Timer

URLのクエリに設定を保存する、OJapp Freeの1P1Aサンプルタイマーです。

```text
/timer/?time=5&mode=down&seconds=on
```

## Query parameters

| Parameter | Values | Description |
| --- | --- | --- |
| `time` | `1`–`60` | タイマー時間（分） |
| `mode` | `down`, `up` | カウント方向 |
| `seconds` | `on`, `off` | 秒表示の有無 |

設定を変更するとURLも更新されます。そのURLをホーム画面へ追加すると、設定済みタイマーとして起動します。

## OJapp query option

このサンプルの `ojapp.js` には、クエリをManifestの `id` と `start_url` に含めるオプションを追加しています。

```html
<meta name="ojapp:query" content="true">
```

このメタタグがないページでは、従来どおりクエリを除いたページURLを使用します。`scope` には常にクエリを含めません。

JavaScriptでクエリを書き換えたあとは、Manifestも更新できます。

```js
history.replaceState(null, "", url);
window.ojappRefreshManifest?.();
```

## Files

```text
ojapp.js
timer/
├── index.html
├── style.css
├── timer.js
└── icon.png
```

GitHub Pagesではリポジトリのルートを公開対象に設定してください。
